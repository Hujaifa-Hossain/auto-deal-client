import React from 'react';

const NotFound = () => {
    return (
        <div>
            <img className="img-fluid w-100" src="https://assets.website-files.com/5c6dab076fc786143a664e6f/5cc88fef71a23e8053658ff7_campfire-01.gif" alt="" />
        </div>
    );
};

export default NotFound;