import React from 'react';

const Pay = () => {
  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <p>Payment system coming soon.</p>
    </div>
  );
};

export default Pay;